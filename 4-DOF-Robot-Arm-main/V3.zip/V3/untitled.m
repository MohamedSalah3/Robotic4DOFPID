
DCMotor_R = 4.999;
DCMotor_L = 0.00031 ; 
DCMotor_K = 0.47777;
DCMotor_Kf = 0.9214;

