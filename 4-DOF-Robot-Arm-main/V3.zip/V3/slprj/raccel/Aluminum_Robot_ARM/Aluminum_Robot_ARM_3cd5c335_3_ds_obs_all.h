#include "__cf_Aluminum_Robot_ARM.h"
#ifdef __cplusplus
extern "C" {
#endif
#ifndef ALUMINUM_ROBOT_ARM_3CD5C335_3_DS_OBS_ALL_H
#define ALUMINUM_ROBOT_ARM_3CD5C335_3_DS_OBS_ALL_H 1
extern int32_T Aluminum_Robot_ARM_3cd5c335_3_ds_obs_all ( const
NeDynamicSystem * sys , const NeDynamicSystemInput * in , NeDsMethodOutput *
ou ) ;
#endif
#ifdef __cplusplus
}
#endif
