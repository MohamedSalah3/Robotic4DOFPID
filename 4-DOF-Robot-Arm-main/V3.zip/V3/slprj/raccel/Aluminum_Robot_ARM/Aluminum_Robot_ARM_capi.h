#include "__cf_Aluminum_Robot_ARM.h"
#ifndef RTW_HEADER_Aluminum_Robot_ARM_capi_h
#define RTW_HEADER_Aluminum_Robot_ARM_capi_h
#include "Aluminum_Robot_ARM.h"
extern void Aluminum_Robot_ARM_InitializeDataMapInfo ( void ) ;
#endif
