#include "__cf_Aluminum_Robot_ARM.h"
#ifndef struct__ExternalFunctionStructTag
#define struct__ExternalFunctionStructTag
#endif
