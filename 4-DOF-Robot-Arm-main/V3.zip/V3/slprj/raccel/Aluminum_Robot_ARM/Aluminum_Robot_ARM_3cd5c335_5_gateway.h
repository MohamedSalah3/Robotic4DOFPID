#include "__cf_Aluminum_Robot_ARM.h"
#ifndef __Aluminum_Robot_ARM_3cd5c335_5_gateway_h__
#define __Aluminum_Robot_ARM_3cd5c335_5_gateway_h__
#ifdef __cplusplus
extern "C" {
#endif
extern void Aluminum_Robot_ARM_3cd5c335_5_gateway ( void ) ;
#ifdef __cplusplus
}
#endif
#endif
