#include "__cf_Aluminum_Robot_ARM.h"
#ifndef RTW_HEADER_rtmodel_h_
#define RTW_HEADER_rtmodel_h_
#include "Aluminum_Robot_ARM.h"
#define GRTINTERFACE 1
#endif
