#include "__cf_Aluminum_Robot_ARM.h"
#ifdef __cplusplus
extern "C" {
#endif
#ifndef ALUMINUM_ROBOT_ARM_3CD5C335_5_DS_H
#define ALUMINUM_ROBOT_ARM_3CD5C335_5_DS_H 1
extern NeDynamicSystem * Aluminum_Robot_ARM_3cd5c335_5_dae_ds ( PmAllocator *
allocator ) ;
#endif
#ifdef __cplusplus
}
#endif
