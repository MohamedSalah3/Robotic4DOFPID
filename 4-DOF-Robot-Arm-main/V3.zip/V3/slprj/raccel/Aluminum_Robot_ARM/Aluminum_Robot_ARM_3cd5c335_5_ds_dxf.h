#include "__cf_Aluminum_Robot_ARM.h"
#ifdef __cplusplus
extern "C" {
#endif
#ifndef ALUMINUM_ROBOT_ARM_3CD5C335_5_DS_DXF_H
#define ALUMINUM_ROBOT_ARM_3CD5C335_5_DS_DXF_H 1
extern int32_T Aluminum_Robot_ARM_3cd5c335_5_ds_dxf ( const NeDynamicSystem *
sys , const NeDynamicSystemInput * in , NeDsMethodOutput * ou ) ;
#endif
#ifdef __cplusplus
}
#endif
