#include "__cf_Aluminum_Robot_ARM.h"
#ifndef RTW_HEADER_Aluminum_Robot_ARM_types_h_
#define RTW_HEADER_Aluminum_Robot_ARM_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
typedef struct P_ P ;
#endif
